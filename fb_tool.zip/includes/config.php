<?php
	$con = mysqli_connect("localhost","root","root",""); 
	//$con = mysqli_connect("localhost","builder_work","builder_work1244","builder_work");
	mysqli_set_charset($con, "utf8") 

 ?>